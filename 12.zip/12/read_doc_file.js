const fs = require('fs')
const {
  Document,
  Packer,
  Paragraph,
  TextRun,
  AlignmentType,
  HeadingLevel,
} = require('docx')

// -----------------------------
// Data
// -----------------------------
const data = {
  school: 'S.G.M PUBLIC SCHOOL',
  exam: 'Half Yearly Examination – 2025-26',
  class: 'Class – 3ʳᵈ',
  time: 'Time – 2hr',
  subject: 'Subject – Computer',
  mm: 'M.M – 60',

  mcq: [
    {
      q: 'Always you to set a theme for windows.',
      op: ['Window Theme', 'Display Desktop', 'Sounds', 'None of above'],
    },
    {
      q: 'A ______ is a container you can use to store files in.',
      op: ['File', 'Folder', 'Program', 'None of above'],
    },
    {
      q: 'The ______ tab has display options like zoom and ruler visibility.',
      op: ['View', 'Edit', 'Insert', 'None of above'],
    },
  ],

  trueFalse: [
    'Wordpad has four options for printing documents.',
    'Use document library to organize your digital pictures.',
    'Desktop is the main Windows 7 screen.',
    'In WordPad the second tab is named home.',
  ],

  fillUps: [
    'To delete text select the text and press ______.',
    'To change font, font style or font size click on ______.',
    'Use ______ library to organize documents, spreadsheets and presentations.',
    'Display any program you have running.',
  ],

  short: [
    'Write names of the icons found on desktop?',
    'What is cursor?',
    'What is the use of folder?',
    'What is the use of Taskbar?',
  ],
}

// -----------------------------
// Build document
// -----------------------------
const doc = new Document({
  sections: [
    {
      children: [
        // SCHOOL NAME
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({
              text: data.school,
              bold: true,
              size: 48, // 24pt
            }),
          ],
        }),

        // Exam Name
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
          children: [
            new TextRun({
              text: data.exam,
              bold: true,
              size: 36,
            }),
          ],
        }),

        // Class & Subject Line
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 100 },
          children: [
            new TextRun({
              text: `${data.class} — ${data.subject}`,
              bold: true,
              size: 32,
            }),
          ],
        }),

        // TIME LEFT – MM RIGHT
        new Paragraph({
          alignment: AlignmentType.JUSTIFY,
          spacing: { after: 300 },
          children: [
            new TextRun({ text: data.time, size: 28 }),
            new TextRun({
              text: ' '.repeat(70) + data.mm,
              size: 28,
            }),
          ],
        }),

        // ------------------ MCQ ---------------------
        new Paragraph({
          text: 'Multiple Choice Questions:',
          heading: HeadingLevel.HEADING_3,
        }),

        ...data.mcq
          .map((item, index) => [
            new Paragraph({
              spacing: { before: 200 },
              children: [
                new TextRun({
                  text: `${index + 1}. ${item.q}`,
                  bold: true,
                  size: 28,
                }),
              ],
            }),

            // 2 options per line formatted beautifully
            new Paragraph({
              children: [
                new TextRun({ text: `(i) ${item.op[0]}`, size: 26 }),
                new TextRun({ text: ' '.repeat(20) }),
                new TextRun({ text: `(ii) ${item.op[1]}`, size: 26 }),
              ],
            }),

            new Paragraph({
              children: [
                new TextRun({ text: `(iii) ${item.op[2]}`, size: 26 }),
                new TextRun({ text: ' '.repeat(17) }),
                new TextRun({ text: `(iv) ${item.op[3]}`, size: 26 }),
              ],
            }),
          ])
          .flat(),

        // ------------------ TRUE / FALSE ---------------------
        new Paragraph({
          text: '\nWrite True or False:',
          heading: HeadingLevel.HEADING_3,
        }),

        ...data.trueFalse.map(
          (q, i) =>
            new Paragraph({
              children: [new TextRun({ text: `${i + 1}. ${q}`, size: 28 })],
            })
        ),

        // ------------------ FILL UPS ---------------------
        new Paragraph({
          text: '\nFill in the blanks:',
          heading: HeadingLevel.HEADING_3,
        }),

        ...data.fillUps.map(
          (q, i) =>
            new Paragraph({
              children: [new TextRun({ text: `${i + 1}. ${q}`, size: 28 })],
            })
        ),

        // ------------------ SHORT ANSWERS ---------------------
        new Paragraph({
          text: '\nAnswer the following questions:',
          heading: HeadingLevel.HEADING_3,
        }),

        ...data.short.map(
          (q, i) =>
            new Paragraph({
              children: [new TextRun({ text: `${i + 1}. ${q}`, size: 28 })],
            })
        ),
      ],
    },
  ],
})

// Save File
Packer.toBuffer(doc).then((buffer) => {
  fs.writeFileSync('Perfect_Exam_Format.docx', buffer)
  console.log('Perfect_Exam_Format.docx created!')
})
