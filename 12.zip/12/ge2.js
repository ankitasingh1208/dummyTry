const fs = require('fs')
const {
  Document,
  Packer,
  Paragraph,
  TextRun,
  AlignmentType,
  HeadingLevel,
  PageBreak,
} = require('docx')

// -----------------------------
// DATA
// -----------------------------
// const data = {
//   school: 'S.G.M PUBLIC SCHOOL',
//   exam: 'Half Yearly Examination – 2025-26',
//   class: 'Class – 3rd',
//   subject: 'Subject – Computer',

//   time: 'Time – 2hr',
//   mm: 'M.M – 60',

//   mcq: [
//     {
//       q: 'Always you to set a theme for windows.',
//       op: ['Window Theme', 'Display Desktop', 'Sounds', 'None of above'],
//     },
//     {
//       q: 'A ______ is a container you can use to store files in.',
//       op: ['File', 'Folder', 'Program', 'None of above'],
//     },
//     {
//       q: 'The ______ tab has display options like zoom and ruler visibility.',
//       op: ['View', 'Edit', 'Insert', 'None of above'],
//     },
//   ],

//   tf: [
//     'Wordpad has four options for printing documents.',
//     'Use document library to organize your digital pictures.',
//     'Desktop is the main Windows 7 screen.',
//     'In WordPad the second tab is named home.',
//   ],

//   fill: [
//     'To delete text select the text and press ______.',
//     'To change font, font style or font size click on ______.',
//     'Use ______ library to organize documents and spreadsheets.',
//     'Display any program you have running.',
//   ],

//   short: [
//     'Write names of the icons found on desktop?',
//     'What is cursor?',
//     'What is the use of folder?',
//     'What is the use of Taskbar?',
//   ],
// }


const data = {
  school: 'S.G.M PUBLIC SCHOOL',
  exam: 'Half Yearly Examination – 2025-26',
  class: 'Class – 3rd',
  subject: 'Subject – Hindi',

  time: 'Time – 2hr',
  mm: 'M.M – 60',

  // =======================
  // MULTIPLE CHOICE QUESTIONS
  // =======================
  mcq: [
    {
      q: '“कमल” किसका नाम है?',
      op: ['फूल', 'फल', 'जानवर', 'पक्षी'],
    },
    {
      q: 'किस शब्द का अर्थ “बहादुर” होता है?',
      op: ['कायर', 'वीर', 'दुखी', 'धीमा'],
    },
    {
      q: '“जल” का समानार्थी शब्द क्या है?',
      op: ['पानी', 'आग', 'हवा', 'धरती'],
    },
  ],

  // =======================
  // TRUE / FALSE
  // =======================
  tf: [
    'हवा दिखाई देती है।',
    'गाय शाकाहारी जानवर है।',
    'सूरज पूर्व दिशा से उगता है।',
    'कमल जमीन पर उगता है।',
  ],

  // =======================
  // FILL IN THE BLANKS
  // =======================
  fill: [
    'भारत का राष्ट्रीय पशु ______ है।',
    'सूरज ______ दिशा से उगता है।',
    '______ से हमें ताजी हवा मिलती है।',
    'नीलकंठ एक प्रकार का ______ है।',
  ],

  // =======================
  // SHORT QUESTIONS
  // =======================
  short: [
    'भारत का राष्ट्रीय फूल का नाम लिखिए।',
    'आपका पसंदीदा फल कौन-सा है और क्यों?',
    'पेड़ों से हमें क्या-क्या मिलता है?',
    '“विद्यालय” का अर्थ अपने शब्दों में लिखिए।',
  ],
}


// -----------------------------
// Create Document (section with proper header objects)
// -----------------------------
const doc = new Document({
  sections: [
    {
      properties: {
        page: {
          margin: { top: 720, bottom: 720, left: 720, right: 720 },
        },
      },

      children: [
        // School name (center large)
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 100 },
          children: [
            new TextRun({
              text: data.school,
              bold: true,
              size: 48,
              font: 'Times New Roman', // change font here
              color: '000000',
            }),
          ],
        }),

        // Exam title
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
          children: [new TextRun({ text: data.exam, bold: true, size: 32 })],
        }),

        // Class on its own line
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: data.class, bold: true, size: 36 })],
        }),

        // Subject on its own line
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 150 },
          children: [new TextRun({ text: data.subject, bold: true, size: 36 })],
        }),

        // Time (left) and MM (right) — we approximate using spacing
        new Paragraph({
          spacing: { after: 100 },
          children: [
            new TextRun({ text: '  ', text: data.time, size: 28 }),
            new TextRun({ text: '  '.repeat(77) }), // spacing to push MM to approximate right
            new TextRun({ text: data.mm, size: 28 }),
          ],
        }),

        // Horizontal line
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
          children: [
            new TextRun({
              text: '_'.repeat(103),
              bold: true,
            }),
          ],
        }),

        // ========= MCQ =========
        new Paragraph({
          text: 'Multiple Choice Questions:',
          heading: HeadingLevel.HEADING_2,
          spacing: { after: 200 },
        }),

        ...data.mcq
          .map((item, i) => [
            new Paragraph({
              spacing: { before: 100, after: 60 },
              children: [
                new TextRun({
                  text: `${i + 1}. ${item.q}`,
                  bold: true,
                  size: 28,
                }),
              ],
            }),
            new Paragraph({
              indent: { left: 720 },
              children: [
                new TextRun({ text: `(i) ${item.op[0]}`, size: 26 }),
                new TextRun({ text: ' '.repeat(30) }),
                new TextRun({ text: `(ii) ${item.op[1]}`, size: 26 }),
              ],
            }),
            new Paragraph({
              indent: { left: 720 },
              spacing: { after: 150 },
              children: [
                new TextRun({ text: `(iii) ${item.op[2]}`, size: 26 }),
                new TextRun({ text: ' '.repeat(26) }),
                new TextRun({ text: `(iv) ${item.op[3]}`, size: 26 }),
              ],
            }),
          ])
          .flat(),

        // Page break to next section
        // new Paragraph({ children: [new PageBreak()] }),

        // ========= True / False =========
        new Paragraph({
          text: 'Write True or False:',
          heading: HeadingLevel.HEADING_2,
          spacing: { after: 200 },
        }),

        ...data.tf.map(
          (q, i) =>
            new Paragraph({
              spacing: { after: 120 },
              children: [
                new TextRun({ text: `${i + 1}. ${q}`, size: 28 }),
                new TextRun({ text: '(  ) ', size: 28 }),
              ],
            })
        ),

        // new Paragraph({ children: [new PageBreak()] }),

        // ========= Fill in the blanks =========
        new Paragraph({
          text: 'Fill in the blanks:',
          heading: HeadingLevel.HEADING_2,
          spacing: { after: 200 },
        }),

        ...data.fill.map(
          (q, i) =>
            new Paragraph({
              spacing: { after: 120 },
              children: [new TextRun({ text: `${i + 1}. ${q}`, size: 28 })],
            })
        ),

        // new Paragraph({ children: [new PageBreak()] }),

        // ========= Short Answers =========
        new Paragraph({
          text: 'Answer the following questions:',
          heading: HeadingLevel.HEADING_2,
          spacing: { after: 200 },
        }),

        ...data.short.map(
          (q, i) =>
            new Paragraph({
              spacing: { after: 120 },
              children: [new TextRun({ text: `${i + 1}. ${q}`, size: 28 })],
            })
        ),
      ],
    },
  ],
})

// -----------------------------
// Write the file
// -----------------------------
Packer.toBuffer(doc)
  .then((buffer) => {
    fs.writeFileSync('class_3_hindi.docx', buffer)
    console.log('✔ Final_Exam_With_Fixed.docx created!')
  })
  .catch((err) => {
    console.error('Error while writing DOCX:', err)
  })
