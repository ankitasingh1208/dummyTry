const fs = require("fs");
const {
  Document,
  Packer,
  Paragraph,
  TextRun,
  AlignmentType,
  HeadingLevel,
  Table,
  TableCell,
  TableRow,
  WidthType,
} = require('docx')

// -----------------------------
// FRACTION HELPER (REAL WORD FRACTION)
// -----------------------------


function fractionTable(top, bottom) {
  return new Table({
    width: { size: 100, type: WidthType.DXA }, // small width
    borders: {
      top: { style: 'none' },
      bottom: { style: 'none' },
      left: { style: 'none' },
      right: { style: 'none' },
      insideHorizontal: { style: 'single', size: 2 }, // horizontal line
      insideVertical: { style: 'none' },
    },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [new TextRun({ text: String(top), size: 28 })],
              }),
            ],
          }),
        ],
      }),
      new TableRow({
        children: [
          new TableCell({
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [new TextRun({ text: String(bottom), size: 28 })],
              }),
            ],
          }),
        ],
      }),
    ],
  })
}


// -----------------------------
// DATA (CLASS 3 MATHS)
// -----------------------------
const data = {
  school: 'S.G.M PUBLIC SCHOOL',
  exam: 'Half Yearly Examination – 2025-26',
  class: 'Class – 3rd',
  subject: 'Subject – Mathematics',

  time: 'Time – 2hr',
  mm: 'M.M – 60',

  mcq: [
    {
      q: 'Which of the following represents half?',
      op: ['1\n—\n4', '1\n—\n2', '2\n—\n3', '3\n—\n4'],
    },
    {
      q: 'What is 6 × 7 ?',
      op: ['42', '36', '40', '48'],
    },
    {
      q: 'What is 45 ÷ 5 ?',
      op: ['5', '8', '9', '10'],
    },
  ],

  tf: [
    `7 × 5 = 35.`,
    `A square has 3 sides.`,
    `1/2 is greater than 3/4.`,
    `Addition and subtraction are opposite operations.`,
    `Even numbers end with 0,2,4,6,8.`,
  ],

  fill: [
    '6 × 9 = ______.',
    'The number after 499 is ______.',
    ['The fraction of one part out of four equal parts is ', fractionTable(1, 4)],
    '12 ÷ 3 = ______.',
    'A shape with 4 equal sides is called ______.',
    '250 + 340 = ______.',
    '5 tens = ______.',
  ],

  short: [
    'Solve: 87 − 49.',
    'Write expanded form of 786.',
    ['Draw the fraction ', fractionTable(1, 4)],
    'Solve: 36 ÷ 4.',
    'Place value of 7 in 472?',
    'Write any 4 even numbers.',
    'Find perimeter of rectangle (6 cm, 4 cm).',
  ],
}

// -----------------------------
// DOCUMENT
// -----------------------------
const doc = new Document({
  sections: [
    {
      properties: {
        page: {
          margin: { top: 720, bottom: 720, left: 720, right: 720 },
        },
      },

      children: [
        // SCHOOL
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 100 },
          children: [
            new TextRun({ text: data.school, bold: true, size: 48 }),
          ],
        }),

        // EXAM
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 150 },
          children: [
            new TextRun({ text: data.exam, bold: true, size: 32 }),
          ],
        }),

        // CLASS
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: data.class, bold: true, size: 36 }),
          ],
        }),

        // SUBJECT
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
          children: [
            new TextRun({ text: data.subject, bold: true, size: 36 }),
          ],
        }),

        // TIME + MM
        new Paragraph({
          spacing: { after: 120 },
          children: [
            new TextRun({ text: data.time, size: 28 }),
            new TextRun({ text: " ".repeat(65) }),
            new TextRun({ text: data.mm, size: 28 }),
          ],
        }),

        // REAL HR LINE
        new Paragraph({
          border: {
            bottom: {
              color: "000000",
              space: 1,
              value: "single",
              size: 12,
            },
          },
          spacing: { after: 250 },
        }),

        // ========== MCQ =============
        new Paragraph({
          text: "Multiple Choice Questions:",
          heading: HeadingLevel.HEADING_2,
          spacing: { after: 200 },
        }),

        ...data.mcq.map((item, i) => [
          new Paragraph({
            spacing: { after: 80 },
            children: [
              new TextRun({
                text: `${i + 1}. ${item.q}`,
                bold: true,
                size: 28,
              }),
            ],
          }),

          // First row (i) & (ii)
          new Paragraph({
            indent: { left: 720 },
            children: [
              new TextRun({ text: `(i) `, size: 26 }),
              ...(typeof item.op[0] === "string"
                ? [new TextRun({ text: item.op[0], size: 26 })]
                : [item.op[0]]),

              new TextRun(" ".repeat(25)),

              new TextRun({ text: `(ii) `, size: 26 }),
              ...(typeof item.op[1] === "string"
                ? [new TextRun({ text: item.op[1], size: 26 })]
                : [item.op[1]]),
            ],
          }),

          // Second row (iii) & (iv)
          new Paragraph({
            indent: { left: 720 },
            spacing: { after: 150 },
            children: [
              new TextRun({ text: `(iii) `, size: 26 }),
              ...(typeof item.op[2] === "string"
                ? [new TextRun({ text: item.op[2], size: 26 })]
                : [item.op[2]]),

              new TextRun(" ".repeat(22)),

              new TextRun({ text: `(iv) `, size: 26 }),
              ...(typeof item.op[3] === "string"
                ? [new TextRun({ text: item.op[3], size: 26 })]
                : [item.op[3]]),
            ],
          }),
        ]).flat(),

        // ========== TRUE / FALSE =========
        new Paragraph({
          text: "Write True or False:",
          heading: HeadingLevel.HEADING_2,
          spacing: { after: 200 },
        }),

        ...data.tf.map(
          (q, i) =>
            new Paragraph({
              spacing: { after: 120 },
              children: [new TextRun({ text: `${i + 1}. ${q}`, size: 28 })],
            })
        ),

        // ========== FILL UPS =========
        new Paragraph({
          text: "Fill in the blanks:",
          heading: HeadingLevel.HEADING_2,
          spacing: { after: 200 },
        }),

        ...data.fill.map((q, i) => {
          if (Array.isArray(q)) {
            return new Paragraph({
              spacing: { after: 120 },
              children: [
                new TextRun({ text: `${i + 1}. `, size: 28 }),
                new TextRun({ text: q[0], size: 28 }),
                q[1],
              ],
            });
          }

          return new Paragraph({
            spacing: { after: 120 },
            children: [new TextRun({ text: `${i + 1}. ${q}`, size: 28 })],
          });
        }),

        // ========== SHORT ANSWERS =========
        new Paragraph({
          text: "Answer the following questions:",
          heading: HeadingLevel.HEADING_2,
          spacing: { after: 200 },
        }),

        ...data.short.map((q, i) => {
          if (Array.isArray(q)) {
            return new Paragraph({
              spacing: { after: 120 },
              children: [
                new TextRun({ text: `${i + 1}. `, size: 28 }),
                new TextRun({ text: q[0], size: 28 }),
                q[1],
              ],
            });
          }
          return new Paragraph({
            spacing: { after: 120 },
            children: [new TextRun({ text: `${i + 1}. ${q}`, size: 28 })],
          });
        }),
      ],
    },
  ],
});

// -----------------------------
// Write Output File
// -----------------------------
Packer.toBuffer(doc).then((buffer) => {
  fs.writeFileSync("Class3_Maths_Exam.docx", buffer);
  console.log("✔ Class3_Maths_Exam.docx created with REAL FRACTIONS!");
});
