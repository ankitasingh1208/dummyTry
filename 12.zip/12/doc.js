const fs = require("fs");
const mammoth = require("mammoth");

async function readDocx(filePath) {
  try {
    const result = await mammoth.extractRawText({ path: filePath });
    const text = result.value;

    console.log("\n=========== RAW TEXT ===========\n");
    console.log(text);

    return text;
  } catch (error) {
    console.error("Error reading DOCX:", error);
  }
}

// Call
readDocx("sample.docx");
